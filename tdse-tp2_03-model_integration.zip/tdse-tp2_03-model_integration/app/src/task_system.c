/*
 * Copyright (c) 2026 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"

/********************** macros and definitions *******************************/
#define DEL_SYS_MIN			0ul
#define DEL_SYS_MED			2500ul
#define DEL_SYS_MAX			5000ul		/* 5000 ticks x 1 mS = 5 S (apertura/cierre de barrera) */

/* Modes to excite Task System */
typedef enum task_system_mode {NORMAL, MODE_QTY} task_system_mode_t;

#define SYSTEM_CFG_QTY	MODE_QTY
#define SYSTEM_DTA_QTY	MODE_QTY

/********************** internal data declaration ****************************/
/* Configuración (cfg) de System: Tick máximo */
const task_system_cfg_t task_system_cfg_list[SYSTEM_CFG_QTY] = {
	{DEL_SYS_MAX}		/* NORMAL */
};

/* Datos (dta) de System */
task_system_dta_t task_system_dta_list[SYSTEM_DTA_QTY];

/********************** internal functions declaration ***********************/
void task_system_normal_statechart(void);

void task_system_set_mode(task_system_mode_t);

/********************** internal data definition *****************************/
const char *p_task_system 		= "Task System (System Statechart)";
const char *p_task_system_ 		= "Non-Blocking Code";
const char *p_task_system__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/
task_system_mode_t g_task_system_mode;

/********************** external functions definition ************************/
void task_system_init(void *parameters)
{
	uint32_t index;
	task_system_dta_t 	*p_task_system_dta;
	task_system_st_t	state;
	task_system_ev_t	event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_system_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system__);

	init_event_task_system();

	task_system_set_mode(NORMAL);

	for (index = 0; SYSTEM_DTA_QTY > index; index++)
	{
		/* Update Task System Data Pointer */
		p_task_system_dta = &task_system_dta_list[index];

		/* Init & Print out: Task execution FSM */
		p_task_system_dta->tick = DEL_SYS_MIN;

		state = ST_SYS_WAIT_FOR_CAR_ARRIEVE;
		p_task_system_dta->state = state;

		event = EV_SYS_IDLE;
		p_task_system_dta->event = event;

		b_event = false;
		p_task_system_dta->flag = b_event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %s",
					GET_NAME(state), (uint32_t)state,
					GET_NAME(event), (uint32_t)event,
					GET_NAME(b_event), (b_event ? "true" : "false"));
	}

	/* Transición inicial (main region): barrera cerrada */
	put_event_task_actuator(EV_LED_OFF, ID_LED_BARRIER_OPEN);
	put_event_task_actuator(EV_LED_ON, ID_LED_BARRIER_CLOSE);

	task_system_set_mode(NORMAL);
}

void task_system_update(void *parameters)
{
	/* Run Task Statechart */
	switch (g_task_system_mode)
	{
		case NORMAL:

			task_system_normal_statechart();

			break;

		default:

			task_system_set_mode(NORMAL);

			break;
	}
}

void task_system_normal_statechart(void)
{
	const task_system_cfg_t *p_task_system_cfg;
	task_system_dta_t *p_task_system_dta;

	/* Update Task System Configuration & Data Pointer */
	p_task_system_cfg = &task_system_cfg_list[NORMAL];
	p_task_system_dta = &task_system_dta_list[NORMAL];

	/* Get next event (signal) from Task Sensor */
	if (true == any_event_task_system())
	{
		p_task_system_dta->flag = true;
		p_task_system_dta->event = get_event_task_system();
	}

	switch (p_task_system_dta->state)
	{
		case ST_SYS_WAIT_FOR_CAR_ARRIEVE:

			/* EV_SYS_CAMERA */
			if ((true == p_task_system_dta->flag) && (EV_SYS_CAMERA == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_WAIT_FOR_BUTTON_PRESSED;
			}

			break;

		case ST_SYS_WAIT_FOR_BUTTON_PRESSED:

			/* EV_SYS_BUTTON / tick = DEL_SYS_MAX; LED_BARRIER_OPEN = BLINK; LED_BARRIER_CLOSE = OFF */
			if ((true == p_task_system_dta->flag) && (EV_SYS_BUTTON == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				p_task_system_dta->tick = p_task_system_cfg->tick_max;
				put_event_task_actuator(EV_LED_BLINK, ID_LED_BARRIER_OPEN);
				put_event_task_actuator(EV_LED_OFF, ID_LED_BARRIER_CLOSE);
				p_task_system_dta->state = ST_SYS_WAIT_FOR_BARRIER_OPENED;
			}

			break;

		case ST_SYS_WAIT_FOR_BARRIER_OPENED:

			/* 1: [tick == 0] / LED_BARRIER_OPEN = ON */
			if (DEL_SYS_MIN == p_task_system_dta->tick)
			{
				put_event_task_actuator(EV_LED_ON, ID_LED_BARRIER_OPEN);
				p_task_system_dta->state = ST_SYS_WAIT_FOR_CAR_LEAVES;
			}
			/* 2: [tick > 0] / tick-- */
			else
			{
				p_task_system_dta->tick--;
			}

			break;

		case ST_SYS_WAIT_FOR_CAR_LEAVES:

			/* EV_SYS_SENSOR_COIL / tick = DEL_SYS_MAX; LED_BARRIER_OPEN = OFF; LED_BARRIER_CLOSE = BLINK */
			if ((true == p_task_system_dta->flag) && (EV_SYS_SENSOR_COIL == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				p_task_system_dta->tick = p_task_system_cfg->tick_max;
				put_event_task_actuator(EV_LED_OFF, ID_LED_BARRIER_OPEN);
				put_event_task_actuator(EV_LED_BLINK, ID_LED_BARRIER_CLOSE);
				p_task_system_dta->state = ST_SYS_WAIT_FOR_BARRIER_CLOSED;
			}

			break;

		case ST_SYS_WAIT_FOR_BARRIER_CLOSED:

			/* 1: [tick == 0] / LED_BARRIER_CLOSE = ON */
			if (DEL_SYS_MIN == p_task_system_dta->tick)
			{
				put_event_task_actuator(EV_LED_ON, ID_LED_BARRIER_CLOSE);
				p_task_system_dta->state = ST_SYS_WAIT_FOR_CAR_ARRIEVE;
			}
			/* 2: [tick > 0] / tick-- */
			else
			{
				p_task_system_dta->tick--;
			}

			break;

		default:

			p_task_system_dta->tick  = DEL_SYS_MIN;
			p_task_system_dta->state = ST_SYS_WAIT_FOR_CAR_ARRIEVE;
			p_task_system_dta->event = EV_SYS_IDLE;
			p_task_system_dta->flag  = false;

			break;
	}

	/* Evento no usado por el estado actual: se descarta */
	p_task_system_dta->flag = false;
}

void task_system_set_mode(task_system_mode_t task_system_mode)
{
	g_task_system_mode = task_system_mode;
}

/********************** end of file ******************************************/
